
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, Post, PostCategory, Event, Message, Poll, Complaint, Resource, Report, Exam } from './types';

interface AppState {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  posts: Post[];
  addPost: (post: Post) => void;
  events: Event[];
  addEvent: (event: Event) => void;
  messages: Message[];
  addMessage: (msg: Message) => void;
  polls: Poll[];
  setPolls: React.Dispatch<React.SetStateAction<Poll[]>>;
  complaints: Complaint[];
  addComplaint: (c: Complaint) => void;
  reports: Report[];
  addReport: (r: Report) => void;
  updateReportStatus: (id: string, status: Report['status']) => void;
  resources: Resource[];
  addResource: (res: Resource) => void;
  exams: Exam[];
  addExam: (exam: Exam) => void;
  updateExam: (exam: Exam) => void;
  deleteExam: (id: string) => void;
  users: User[];
  registerUser: (user: User) => void;
  updatePoints: (userId: string, amount: number) => void;
  // Added sessionLanguage and setSessionLanguage to AppState to support the LanguagePicker component
  sessionLanguage: string;
  setSessionLanguage: (lang: string) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  // Added sessionLanguage state to satisfy component requirements
  const [sessionLanguage, setSessionLanguage] = useState('en');
  
  const [users, setUsers] = useState<User[]>([
    { id: 't1', username: 'teacher', name: 'Mr. Smith', role: UserRole.TEACHER, profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=teacher&backgroundColor=b6e3f4', points: 500 },
    { id: 'p1', username: 'principal', name: 'Dr. Sharma', role: UserRole.PRINCIPAL, profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=principal&backgroundColor=ffdfbf', points: 1000 },
    { id: 's1', username: 'student', name: 'Ashish Kumar', role: UserRole.STUDENT, profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=student&backgroundColor=c0aede', points: 250, house: 'Red', club: 'Coding' }
  ]);

  useEffect(() => {
    setPosts([
      { id: '1', userId: 'p1', userName: 'Dr. Sharma', userRole: UserRole.PRINCIPAL, content: 'Exciting News! We are launching the Digital Library today.', category: PostCategory.NEWS, timestamp: Date.now() - 3600000, likes: 50, isVerified: true },
      { id: '2', userId: 's1', userName: 'Ashish Kumar', userRole: UserRole.STUDENT, content: 'Winning the inter-school coding hackathon!', category: PostCategory.ACADEMICS, timestamp: Date.now() - 7200000, likes: 120 }
    ]);

    setPolls([
      { id: 'poll1', question: 'Should we have a winter carnival?', options: [{ text: 'Yes', votes: 45 }, { text: 'No', votes: 5 }], voters: [], createdBy: 't1' }
    ]);

    setEvents([
      { id: 'e1', title: 'Maths Unit Test', date: '2024-06-01', type: 'EXAM', description: 'Geometry & Calculus' },
      { id: 'e2', title: 'Parent Teacher Meeting', date: '2024-06-05', type: 'PTM', description: 'Annual review' }
    ]);

    setResources([
      { id: 'r1', title: 'Calculus Basics', subject: 'Mathematics', type: 'PDF', url: '#', uploadedBy: 'Mr. Smith', timestamp: Date.now() },
      { id: 'r2', title: 'Organic Chemistry Notes', subject: 'Science', type: 'NOTE', url: '#', uploadedBy: 'Mr. Smith', timestamp: Date.now() - 86400000 }
    ]);

    setReports([
      { id: 'rep1', content: 'Inappropriate behavior observed in the sports hallway.', type: 'Behavior', timestamp: Date.now() - 172800000, status: 'Unread' },
      { id: 'rep2', content: 'Concern regarding the scheduling of extra-curricular activities.', type: 'Academic', timestamp: Date.now() - 86400000, status: 'Reviewed' }
    ]);

    setExams([
      {
        id: 'ex1',
        userId: 't1',
        subject: 'Mathematics',
        date: new Date(Date.now() + 86400000 * 7).toISOString(),
        time: '10:00 AM',
        syllabus: 'Algebra, Trigonometry, Calculus',
        color: 'blue',
        topics: [
          { id: 't1', title: 'Revise Integration', isDone: false },
          { id: 't2', title: 'Complete Calculus Exercise', isDone: true }
        ],
        isPinned: true
      }
    ]);
  }, []);

  const addPost = (post: Post) => setPosts(prev => [post, ...prev]);
  const addEvent = (event: Event) => setEvents(prev => [...prev, event]);
  const addMessage = (msg: Message) => setMessages(prev => [...prev, msg]);
  const addComplaint = (c: Complaint) => setComplaints(prev => [c, ...prev]);
  const addReport = (r: Report) => setReports(prev => [r, ...prev]);
  const updateReportStatus = (id: string, status: Report['status']) => {
    setReports(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  };
  const addResource = (res: Resource) => setResources(prev => [res, ...prev]);
  const addExam = (exam: Exam) => setExams(prev => [exam, ...prev]);
  const updateExam = (exam: Exam) => setExams(prev => prev.map(e => e.id === exam.id ? exam : e));
  const deleteExam = (id: string) => setExams(prev => prev.filter(e => e.id !== id));
  const registerUser = (user: User) => setUsers(prev => [...prev, user]);

  const updatePoints = (userId: string, amount: number) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, points: u.points + amount } : u));
    if (currentUser?.id === userId) {
      setCurrentUser(prev => prev ? { ...prev, points: prev.points + amount } : null);
    }
  };

  return (
    <AppContext.Provider value={{ 
      currentUser, setCurrentUser, posts, addPost, events, addEvent, 
      messages, addMessage, polls, setPolls, complaints, addComplaint, 
      reports, addReport, updateReportStatus,
      resources, addResource, exams, addExam, updateExam, deleteExam, users, registerUser,
      updatePoints, sessionLanguage, setSessionLanguage
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
