
import React, { useState, useRef } from 'react';
import { geminiService } from '../services/geminiService';

export const DoubtSolver: React.FC = () => {
  const [question, setQuestion] = useState('');
  const [subject, setSubject] = useState('Science');
  const [language, setLanguage] = useState('English');
  const [answer, setAnswer] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAsk = async () => {
    if (!question.trim() && !preview) return;
    setLoading(true);
    const result = await geminiService.solveDoubt(question, subject, language, preview || undefined);
    setAnswer(result);
    setLoading(false);
  };

  return (
    <div className="bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-800 overflow-hidden">
      <div className="p-8 bg-zinc-800 text-white border-b border-zinc-700">
        <h2 className="text-2xl font-black flex items-center gap-4">
          <i className="fas fa-brain text-emerald-500"></i>
          AI Academic Buddy
        </h2>
        <p className="text-zinc-400 font-medium text-sm mt-2">Upload a photo of your doubt or type it below.</p>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 px-1">Subject</label>
            <select 
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-sm font-bold text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            >
              <option>Science</option>
              <option>Mathematics</option>
              <option>History</option>
              <option>English</option>
              <option>Coding</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 px-1">Language</label>
            <select 
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full p-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-sm font-bold text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            >
              <option>English</option>
              <option>Hindi</option>
              <option>Spanish</option>
              <option>French</option>
              <option>Bengali</option>
            </select>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="relative">
            <textarea
              placeholder="Describe your doubt here..."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full p-5 bg-zinc-950 border border-zinc-800 rounded-2xl text-sm font-medium text-white outline-none min-h-[120px] focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-zinc-600"
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-4 right-4 w-12 h-12 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl flex items-center justify-center transition-all"
            >
              <i className="fas fa-camera"></i>
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
          </div>

          {preview && (
            <div className="relative w-32 h-32 rounded-2xl overflow-hidden border border-zinc-800 group">
              <img src={preview} className="w-full h-full object-cover" />
              <button 
                onClick={() => setPreview(null)}
                className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <i className="fas fa-times text-[10px]"></i>
              </button>
            </div>
          )}
        </div>

        <button
          onClick={handleAsk}
          disabled={loading || (!question.trim() && !preview)}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl shadow-xl shadow-emerald-900/20 transition-all transform hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? <i className="fas fa-circle-notch animate-spin mr-2"></i> : <i className="fas fa-wand-magic-sparkles mr-2"></i>}
          AI Solve Doubt
        </button>

        {answer && (
          <div className="mt-8 p-8 bg-zinc-800/50 rounded-3xl border border-zinc-800 animate-in fade-in slide-in-from-top-4">
            <h3 className="text-[10px] font-black text-emerald-500 uppercase mb-4 flex items-center gap-2">
              <i className="fas fa-check-circle"></i> AI RESOLUTION
            </h3>
            <div className="text-zinc-200 text-sm leading-relaxed whitespace-pre-wrap font-medium">
              {answer}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
