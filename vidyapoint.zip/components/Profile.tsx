
import React, { useState } from 'react';
import { useApp } from '../store';
import { geminiService } from '../services/geminiService';

export const Profile: React.FC = () => {
  const { currentUser, setCurrentUser } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [showResume, setShowResume] = useState(false);
  const [resumeContent, setResumeContent] = useState('');
  const [loading, setLoading] = useState(false);

  // Edit form state
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [editPic, setEditPic] = useState(currentUser?.profilePic || '');
  const [editSubjects, setEditSubjects] = useState(currentUser?.favoriteSubjects?.join(', ') || '');
  const [editHobbies, setEditHobbies] = useState(currentUser?.hobbies?.join(', ') || '');
  const [editSkills, setEditSkills] = useState(currentUser?.skills?.join(', ') || '');

  if (!currentUser) return null;

  const handleSave = () => {
    setCurrentUser({
      ...currentUser,
      name: editName,
      bio: editBio,
      profilePic: editPic,
      favoriteSubjects: editSubjects.split(',').map(s => s.trim()).filter(s => s),
      hobbies: editHobbies.split(',').map(s => s.trim()).filter(s => s),
      skills: editSkills.split(',').map(s => s.trim()).filter(s => s)
    });
    setIsEditing(false);
  };

  const handleAutoSkills = async () => {
    setLoading(true);
    const profileData = `Name: ${editName}, Bio: ${editBio}, Subjects: ${editSubjects}, Hobbies: ${editHobbies}`;
    const skills = await geminiService.extractSkills(profileData);
    if (skills.length > 0) {
      setEditSkills(skills.join(', '));
    }
    setLoading(false);
  };

  const handleGenerateResume = async () => {
    setLoading(true);
    const content = await geminiService.buildResume(currentUser);
    setResumeContent(content || 'Failed to generate resume.');
    setShowResume(true);
    setLoading(false);
  };

  return (
    <div className="bg-zinc-900 rounded-3xl shadow-xl overflow-hidden border border-zinc-800">
      <div className="h-28 bg-gradient-to-r from-zinc-700 to-zinc-800"></div>
      <div className="px-6 pb-6">
        <div className="relative -mt-12 mb-4 group">
          <img 
            src={currentUser.profilePic} 
            className="w-24 h-24 rounded-2xl border-4 border-zinc-900 shadow-2xl object-cover bg-zinc-800" 
          />
          <span className="absolute bottom-0 right-0 bg-emerald-500 w-5 h-5 border-4 border-zinc-900 rounded-full"></span>
        </div>
        
        {isEditing ? (
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Full Name</label>
              <input 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50"
                value={editName}
                onChange={e => setEditName(e.target.value)}
                placeholder="Name"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Profile Photo URL</label>
              <input 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50"
                value={editPic}
                onChange={e => setEditPic(e.target.value)}
                placeholder="Avatar Image URL"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Short Bio</label>
              <textarea 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50 min-h-[80px] resize-none"
                value={editBio}
                onChange={e => setEditBio(e.target.value)}
                placeholder="Tell us about yourself..."
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Favorite Subjects</label>
                <input 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50"
                  value={editSubjects}
                  onChange={e => setEditSubjects(e.target.value)}
                  placeholder="Math, Coding..."
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Hobbies</label>
                <input 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50"
                  value={editHobbies}
                  onChange={e => setEditHobbies(e.target.value)}
                  placeholder="Chess, Gaming..."
                />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Skills</label>
                <button 
                  onClick={handleAutoSkills}
                  disabled={loading}
                  className="text-[9px] font-black text-emerald-500 hover:text-emerald-400 uppercase tracking-widest flex items-center gap-1"
                >
                  {loading ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-magic"></i>}
                  AI Suggest
                </button>
              </div>
              <input 
                className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2 text-sm text-zinc-100 outline-none focus:ring-2 focus:ring-emerald-500/50"
                value={editSkills}
                onChange={e => setEditSkills(e.target.value)}
                placeholder="Problem Solving, Creativity..."
              />
            </div>
            <div className="flex gap-2 pt-2">
              <button onClick={handleSave} className="flex-1 bg-emerald-600 hover:bg-emerald-700 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all">Save Profile</button>
              <button onClick={() => setIsEditing(false)} className="flex-1 bg-zinc-800 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-zinc-400">Cancel</button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-black text-white">{currentUser.name}</h2>
                <p className="text-zinc-500 font-bold text-xs uppercase tracking-widest mt-1">
                  {currentUser.role} {currentUser.class && `• CLASS ${currentUser.class}-${currentUser.section}`}
                </p>
              </div>
              <div className="flex gap-2">
                <button onClick={handleGenerateResume} disabled={loading} className="w-10 h-10 flex items-center justify-center rounded-xl bg-zinc-800 text-emerald-500 hover:bg-emerald-500/10 transition-all shadow-sm">
                  {loading ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-file-invoice"></i>}
                </button>
                <button onClick={() => setIsEditing(true)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-zinc-800 text-zinc-500 hover:text-white transition-all shadow-sm">
                  <i className="fas fa-edit"></i>
                </button>
              </div>
            </div>
            
            <p className="mt-4 text-sm text-zinc-400 font-medium leading-relaxed">{currentUser.bio || "No bio yet. Tap edit to add one!"}</p>

            <div className="mt-6 space-y-4">
              {currentUser.skills && currentUser.skills.length > 0 && (
                <div className="p-4 bg-zinc-800/50 rounded-2xl border border-zinc-800">
                  <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <i className="fas fa-bolt text-emerald-500"></i> AI Skill Passport
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {currentUser.skills.map((s, i) => (
                      <span key={i} className="px-3 py-1.5 bg-zinc-800 rounded-xl border border-zinc-700 text-[10px] font-black text-zinc-100">
                        {s.toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-zinc-800/50 rounded-2xl border border-zinc-800">
                  <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                    <i className="fas fa-book-open text-amber-500"></i> Subjects
                  </h3>
                  <div className="text-[10px] font-bold text-zinc-300">
                    {currentUser.favoriteSubjects?.join(', ') || 'N/A'}
                  </div>
                </div>
                <div className="p-4 bg-zinc-800/50 rounded-2xl border border-zinc-800">
                  <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                    <i className="fas fa-heart text-rose-500"></i> Hobbies
                  </h3>
                  <div className="text-[10px] font-bold text-zinc-300">
                    {currentUser.hobbies?.join(', ') || 'N/A'}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="bg-zinc-800/80 p-4 rounded-2xl text-center border border-zinc-800">
                <div className="text-white font-black text-xl">{currentUser.points}</div>
                <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-tighter">Campus Points</div>
              </div>
              {currentUser.house && (
                <div className="bg-zinc-800/80 p-4 rounded-2xl text-center border border-zinc-800">
                  <div className="text-white font-black text-xl">{currentUser.house}</div>
                  <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-tighter">House Rank</div>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Resume Modal */}
      {showResume && (
        <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <div className="bg-zinc-900 w-full max-w-2xl rounded-[40px] border border-zinc-800 shadow-2xl p-10 flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-white tracking-tight">AI Generated Resume</h2>
              <button onClick={() => setShowResume(false)} className="text-zinc-500 hover:text-white">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar">
              <div className="prose prose-invert max-w-none text-zinc-300 font-medium">
                {resumeContent.split('\n').map((line, i) => (
                  <p key={i} className="mb-2">{line}</p>
                ))}
              </div>
            </div>
            <button 
              onClick={() => window.print()}
              className="mt-8 w-full bg-white text-zinc-950 py-4 rounded-2xl font-black uppercase tracking-widest text-sm shadow-xl hover:bg-zinc-200 transition-all"
            >
              Print Resume
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
