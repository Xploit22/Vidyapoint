
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole } from '../types';
import { geminiService } from '../services/geminiService';

export const Chat: React.FC = () => {
  const { currentUser, messages, addMessage, users } = useApp();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [moderating, setModerating] = useState(false);

  const targets = users.filter(u => 
    currentUser?.role === UserRole.STUDENT ? u.role !== UserRole.STUDENT : true
  ).filter(u => u.id !== currentUser?.id);

  const handleSend = async () => {
    if (!text.trim() || !selectedUser || !currentUser) return;
    setModerating(true);
    const mod = await geminiService.moderateContent(text);
    if (mod.approved) {
      addMessage({
        id: Math.random().toString(36).substr(2, 9),
        senderId: currentUser.id,
        receiverId: selectedUser,
        text,
        timestamp: Date.now(),
        isModerated: true
      });
      setText('');
    } else {
      alert("⚠️ Restricted: " + mod.reason);
    }
    setModerating(false);
  };

  const currentChat = messages.filter(m => 
    (m.senderId === currentUser?.id && m.receiverId === selectedUser) ||
    (m.senderId === selectedUser && m.receiverId === currentUser?.id)
  );

  return (
    <div className="flex bg-zinc-900 rounded-[40px] shadow-2xl overflow-hidden border border-zinc-800 h-[650px]">
      <div className="w-1/3 border-r border-zinc-800 overflow-y-auto p-6 bg-zinc-950/50">
        <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em] mb-6 px-2">School Directory</h3>
        <div className="space-y-3">
          {targets.map(u => (
            <button
              key={u.id}
              onClick={() => setSelectedUser(u.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all border ${selectedUser === u.id ? 'bg-white text-zinc-950 border-white shadow-xl' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}
            >
              <img src={u.profilePic} className="w-12 h-12 rounded-xl object-cover shadow-lg" />
              <div className="text-left overflow-hidden">
                <div className="text-sm font-black truncate">{u.name}</div>
                <div className={`text-[9px] font-bold uppercase opacity-60 tracking-widest mt-1`}>{u.role}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-zinc-950">
        {selectedUser ? (
          <>
            <div className="p-6 border-b border-zinc-800 flex items-center gap-4 bg-zinc-900/50 backdrop-blur-md">
              <img src={users.find(u => u.id === selectedUser)?.profilePic} className="w-10 h-10 rounded-xl" />
              <div>
                <h4 className="font-black text-white text-lg tracking-tight">{users.find(u => u.id === selectedUser)?.name}</h4>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Active Official</span>
                </div>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              {currentChat.map(m => (
                <div key={m.id} className={`flex ${m.senderId === currentUser?.id ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] p-5 rounded-3xl text-sm font-bold shadow-lg ${m.senderId === currentUser?.id ? 'bg-white text-zinc-950 rounded-tr-none' : 'bg-zinc-800 text-zinc-200 rounded-tl-none border border-zinc-700'}`}>
                    {m.text}
                    <div className={`text-[8px] font-black uppercase mt-2 opacity-50 ${m.senderId === currentUser?.id ? 'text-zinc-950' : 'text-zinc-500'}`}>
                      {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-6 bg-zinc-900/50 border-t border-zinc-800 flex gap-4">
              <input
                value={text}
                onChange={e => setText(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSend()}
                placeholder="Message securely..."
                className="flex-1 px-6 py-4 rounded-2xl bg-zinc-950 border border-zinc-800 outline-none text-sm text-white font-bold focus:ring-2 focus:ring-white/10 placeholder:text-zinc-700"
              />
              <button
                disabled={moderating || !text.trim()}
                onClick={handleSend}
                className="w-14 h-14 bg-white text-zinc-950 rounded-2xl flex items-center justify-center hover:bg-zinc-200 transition-all disabled:opacity-50 shadow-xl"
              >
                {moderating ? <i className="fas fa-dna animate-pulse"></i> : <i className="fas fa-paper-plane"></i>}
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-zinc-600">
            <div className="text-center p-12 bg-zinc-900/30 rounded-[40px] border border-zinc-900 shadow-inner">
              <i className="fas fa-comment-dots text-7xl mb-6 opacity-10"></i>
              <p className="font-black uppercase tracking-widest text-xs">Select a verified contact</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
