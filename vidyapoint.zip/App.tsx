
import React, { useState } from 'react';
import { useApp, AppProvider } from './store';
import { Auth } from './components/Auth';
import { Feed } from './components/Feed';
import { Calendar } from './components/Calendar';
import { DoubtSolver } from './components/DoubtSolver';
import { Profile } from './components/Profile';
import { Chat } from './components/Chat';
import { Polls } from './components/Polls';
import { Tools } from './components/Tools';
import { HouseRanking } from './components/HouseRanking';
import { DigitalLibrary } from './components/DigitalLibrary';
import { ExamPlanner } from './components/ExamPlanner';

const Dashboard: React.FC = () => {
  const { currentUser, setCurrentUser } = useApp();
  const [activeTab, setActiveTab] = useState<'feed' | 'doubt' | 'calendar' | 'chat' | 'tools' | 'polls' | 'house' | 'library' | 'exam-planner'>('feed');

  const menuItems = [
    { id: 'feed', icon: 'shapes', label: 'School Wall' },
    { id: 'exam-planner', icon: 'graduation-cap', label: 'Exam Planner' },
    { id: 'doubt', icon: 'lightbulb', label: 'AI Doubt Box' },
    { id: 'library', icon: 'book-bookmark', label: 'Digital Library' },
    { id: 'chat', icon: 'paper-plane', label: 'Direct Chat' },
    { id: 'calendar', icon: 'calendar', label: 'Calendar' },
    { id: 'polls', icon: 'check-double', label: 'Campus Polls' },
    { id: 'house', icon: 'medal', label: 'House Ranks' },
    { id: 'tools', icon: 'wand-magic-sparkles', label: 'AI Career Hub' }
  ];

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col md:flex-row text-zinc-100">
      <aside className="w-full md:w-72 bg-zinc-950 border-r border-zinc-900 flex flex-col sticky top-0 h-screen overflow-hidden">
        <div className="p-8 flex items-center gap-4">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-zinc-950 shadow-2xl shadow-white/10 rotate-3">
             <i className="fas fa-home text-xl"></i>
          </div>
          <div>
            <h1 className="font-black text-2xl tracking-tighter text-white leading-none">VIDYA<span className="text-emerald-500">POINT</span></h1>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mt-1">Smart Campus</p>
          </div>
        </div>

        <nav className="flex-1 px-6 space-y-1.5 overflow-y-auto pb-8">
          {menuItems.map(item => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-sm font-black tracking-tight transition-all border ${activeTab === item.id ? 'bg-white text-zinc-950 border-white shadow-xl' : 'text-zinc-500 border-transparent hover:bg-zinc-900 hover:text-zinc-300'}`}
            >
              <i className={`fas fa-${item.icon} text-lg w-6`}></i> {item.label}
            </button>
          ))}
        </nav>

        <div className="p-6 mt-auto border-t border-zinc-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={currentUser?.profilePic} className="w-10 h-10 rounded-xl border border-zinc-800 object-cover" />
            <div>
              <div className="text-xs font-black text-white truncate max-w-[100px]">{currentUser?.name}</div>
              <div className="text-[9px] font-bold text-zinc-500 uppercase">{currentUser?.role}</div>
            </div>
          </div>
          <button 
            onClick={() => setCurrentUser(null)}
            className="w-10 h-10 flex items-center justify-center rounded-xl text-zinc-600 hover:bg-rose-500/10 hover:text-rose-500 transition-all"
          >
            <i className="fas fa-power-off"></i>
          </button>
        </div>
      </aside>

      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-6">
          <div className="animate-in fade-in slide-in-from-left-4">
            <h2 className="text-4xl font-black text-white tracking-tighter">Namaste, {currentUser?.name}! 👋</h2>
            <p className="text-zinc-500 font-bold text-sm mt-1">Unified Digital Campus Network is active.</p>
          </div>
          
          <div className="flex gap-4">
             {currentUser?.house && (
               <div className="flex items-center gap-4 bg-zinc-900 p-4 rounded-3xl border border-zinc-800 shadow-xl">
                 <div className="bg-amber-500/10 w-10 h-10 rounded-xl flex items-center justify-center text-amber-500">
                   <i className="fas fa-trophy"></i>
                 </div>
                 <div>
                   <div className="text-[9px] font-black text-zinc-500 uppercase leading-none">Your Rank</div>
                   <div className="text-lg font-black text-white">#4 {currentUser.house}</div>
                 </div>
               </div>
             )}
             <div className="flex items-center gap-4 bg-zinc-900 p-4 rounded-3xl border border-zinc-800 shadow-xl">
               <div className="bg-emerald-500/10 w-10 h-10 rounded-xl flex items-center justify-center text-emerald-500">
                 <i className="fas fa-bolt"></i>
               </div>
               <div>
                 <div className="text-[9px] font-black text-zinc-500 uppercase leading-none">Activity</div>
                 <div className="text-lg font-black text-white">{currentUser?.points}</div>
               </div>
             </div>
          </div>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          <div className="xl:col-span-8 space-y-8 animate-in fade-in slide-in-from-bottom-4">
            {activeTab === 'feed' && <Feed />}
            {activeTab === 'exam-planner' && <ExamPlanner />}
            {activeTab === 'doubt' && <DoubtSolver />}
            {activeTab === 'library' && <DigitalLibrary />}
            {activeTab === 'calendar' && <Calendar />}
            {activeTab === 'chat' && <Chat />}
            {activeTab === 'polls' && <Polls />}
            {activeTab === 'tools' && <Tools />}
            {activeTab === 'house' && <HouseRanking />}
          </div>

          <div className="xl:col-span-4 space-y-8 animate-in fade-in slide-in-from-right-4">
            <Profile />
            
            <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 shadow-2xl">
              <h3 className="text-xl font-black flex items-center gap-3 text-white">
                <i className="fas fa-mask text-emerald-500"></i>
                Anonymous Wall
              </h3>
              <p className="text-zinc-500 text-sm mt-2 font-medium">Have a concern? Report it here. Your identity is strictly anonymous.</p>
              <button className="w-full mt-6 bg-white text-zinc-950 font-black py-4 rounded-2xl shadow-xl transition-all transform hover:scale-[1.02] active:scale-95">
                New Anonymous Report
              </button>
            </div>

            <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 shadow-xl">
              <h3 className="font-black text-white flex items-center gap-3 mb-6">
                <i className="fas fa-bullhorn text-emerald-500"></i>
                School Notices
              </h3>
              <div className="space-y-4">
                <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800">
                  <span className="text-[9px] font-black uppercase text-emerald-500 tracking-widest">Official Verified ✓</span>
                  <p className="text-xs font-bold text-zinc-400 mt-2">Annual Science Exhibition models must be submitted by Friday afternoon.</p>
                </div>
                <div className="p-4 bg-zinc-950 rounded-2xl border border-zinc-800">
                  <span className="text-[9px] font-black uppercase text-rose-500 tracking-widest">Urgent Notice</span>
                  <p className="text-xs font-bold text-zinc-400 mt-2">Mid-term exam schedules have been revised. Check the planner tab.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const AppContent: React.FC = () => {
  const { currentUser } = useApp();
  if (!currentUser) return <Auth />;
  return <Dashboard />;
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
