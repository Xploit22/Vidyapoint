
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole, Resource } from '../types';

export const DigitalLibrary: React.FC = () => {
  const { resources, addResource, currentUser, updatePoints } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showRewardToast, setShowRewardToast] = useState(false);

  // New Resource Form State
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('Mathematics');
  const [newType, setNewType] = useState<Resource['type']>('PDF');
  const [newUrl, setNewUrl] = useState('');

  const subjects = ['All', 'Mathematics', 'Science', 'History', 'English', 'Coding', 'Art'];
  const isStaff = currentUser?.role === UserRole.PRINCIPAL || currentUser?.role === UserRole.TEACHER;

  const filteredResources = resources.filter(res => {
    const matchesSearch = res.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          res.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'All' || res.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const handleAddResource = () => {
    if (!newTitle || !newUrl || !currentUser) return;
    const res: Resource = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTitle,
      subject: newSubject,
      type: newType,
      url: newUrl,
      uploadedBy: currentUser?.name || 'Unknown',
      timestamp: Date.now()
    };
    
    // Add the resource to library
    addResource(res);
    
    // Reward the user with points
    updatePoints(currentUser.id, 50);
    
    // UI Feedback
    setShowRewardToast(true);
    setTimeout(() => setShowRewardToast(false), 3000);

    setShowAddModal(false);
    setNewTitle('');
    setNewUrl('');
  };

  return (
    <div className="space-y-8 pb-20 relative">
      {/* Reward Notification */}
      {showRewardToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[60] bg-emerald-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest shadow-2xl animate-in slide-in-from-top-10 flex items-center gap-4">
          <i className="fas fa-bolt text-amber-300"></i>
          Contribution Reward: +50 Points Granted!
        </div>
      )}

      {/* Header & Controls */}
      <div className="bg-zinc-900 rounded-[32px] p-8 border border-zinc-800 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex-1 relative">
            <i className="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600"></i>
            <input 
              type="text"
              placeholder="Search library for notes, PDFs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-5 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all placeholder:text-zinc-700 font-bold"
            />
          </div>
          <div className="flex gap-4">
            {isStaff && (
              <button 
                onClick={() => setShowAddModal(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-emerald-900/20 transition-all flex items-center gap-2"
              >
                <i className="fas fa-upload"></i> Upload Material
              </button>
            )}
          </div>
        </div>

        {/* Subject Filter */}
        <div className="flex flex-wrap gap-2 mt-6">
          {subjects.map(sub => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-5 py-2.5 text-[9px] font-black uppercase tracking-widest rounded-xl border transition-all ${selectedSubject === sub ? 'bg-white text-zinc-950 border-white shadow-xl' : 'bg-zinc-950 text-zinc-500 border-zinc-800 hover:border-zinc-700'}`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {/* Resource Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredResources.map(res => (
          <div key={res.id} className="bg-zinc-900 rounded-[32px] border border-zinc-800 p-8 hover:border-zinc-700 transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="w-14 h-14 bg-zinc-950 rounded-2xl flex items-center justify-center text-emerald-500 text-xl border border-zinc-800 shadow-lg">
                <i className={`fas ${res.type === 'PDF' ? 'fa-file-pdf' : res.type === 'VIDEO' ? 'fa-play-circle' : 'fa-sticky-note'}`}></i>
              </div>
              <span className="text-[9px] font-black uppercase tracking-widest bg-zinc-950 text-zinc-500 px-3 py-1.5 rounded-full border border-zinc-800">
                {res.subject}
              </span>
            </div>
            <h3 className="text-xl font-black text-white tracking-tight mb-2 group-hover:text-emerald-500 transition-colors">{res.title}</h3>
            <div className="flex items-center gap-3 text-zinc-500 text-[10px] font-bold uppercase tracking-widest mb-6">
              <i className="fas fa-user-circle"></i> {res.uploadedBy}
              <span>•</span>
              <i className="fas fa-clock"></i> {new Date(res.timestamp).toLocaleDateString()}
            </div>
            <a 
              href={res.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full block bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-white text-center font-black py-4 rounded-2xl text-[10px] uppercase tracking-widest transition-all"
            >
              Access Resource <i className="fas fa-external-link-alt ml-2"></i>
            </a>
          </div>
        ))}

        {filteredResources.length === 0 && (
          <div className="col-span-full py-20 text-center bg-zinc-900 rounded-[32px] border border-dashed border-zinc-800">
            <i className="fas fa-book-open text-6xl text-zinc-800 mb-6"></i>
            <h4 className="text-zinc-500 font-black uppercase tracking-widest text-sm">No resources found in this shelf</h4>
          </div>
        )}
      </div>

      {/* Add Resource Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-md z-50 flex items-center justify-center p-6">
          <div className="bg-zinc-900 w-full max-w-lg rounded-[40px] border border-zinc-800 shadow-2xl p-10 animate-in zoom-in-95">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-white tracking-tight">Add Study Material</h2>
              <button onClick={() => setShowAddModal(false)} className="text-zinc-500 hover:text-white">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            <div className="space-y-5">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Resource Title</label>
                <input 
                  type="text" 
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:ring-2 focus:ring-emerald-500/50"
                  placeholder="e.g. Chapter 1 Summary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Subject</label>
                  <select 
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none"
                  >
                    {subjects.slice(1).map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Type</label>
                  <select 
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none"
                  >
                    <option value="PDF">PDF Document</option>
                    <option value="NOTE">Study Note</option>
                    <option value="VIDEO">Video Lecture</option>
                    <option value="LINK">External Link</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Resource Link / URL</label>
                <input 
                  type="text" 
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:ring-2 focus:ring-emerald-500/50"
                  placeholder="https://..."
                />
              </div>
              <button 
                onClick={handleAddResource}
                className="w-full bg-white text-zinc-950 py-5 rounded-2xl font-black uppercase tracking-widest text-sm shadow-xl hover:bg-zinc-200 transition-all mt-4"
              >
                Publish to Library
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
