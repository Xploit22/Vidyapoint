
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole } from '../types';

export const Auth: React.FC = () => {
  const { setCurrentUser, registerUser, users } = useApp();
  const [isSignUp, setIsSignUp] = useState(false);
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username) return;
    
    if (isSignUp) {
      const newUser = {
        id: Math.random().toString(36).substr(2, 9),
        username,
        name: name || username,
        role,
        class: role === UserRole.STUDENT ? '12' : undefined,
        section: role === UserRole.STUDENT ? 'A' : undefined,
        profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}&backgroundColor=b6e3f4,c0aede,ffdfbf,d1d4f9`,
        points: role === UserRole.STUDENT ? 100 : 0,
        house: role === UserRole.STUDENT ? 'Blue' : undefined,
        bio: `New ${role} at Vidyapoint.`
      };
      registerUser(newUser);
      setCurrentUser(newUser);
    } else {
      const existingUser = users.find(u => u.username === username);
      if (existingUser) {
        setCurrentUser(existingUser);
      } else {
        let displayName = username.charAt(0).toUpperCase() + username.slice(1);
        if (username === 'principal') displayName = 'Dr. Sharma';
        if (username === 'teacher') displayName = 'Mr. Smith';
        if (username === 'student') displayName = 'Ashish Kumar';

        setCurrentUser({
          id: username === 'principal' ? 'p1' : username === 'teacher' ? 't1' : 's1',
          username,
          name: displayName,
          role,
          class: role === UserRole.STUDENT ? '12' : undefined,
          section: role === UserRole.STUDENT ? 'A' : undefined,
          profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}&backgroundColor=b6e3f4,c0aede,ffdfbf,d1d4f9`,
          points: role === UserRole.STUDENT ? 150 : 1000,
          house: role === UserRole.STUDENT ? 'Red' : undefined,
          bio: `Verified ${role} of Vidyapoint Smart Campus.`
        });
      }
    }
  };

  const setDefaults = (selectedRole: UserRole) => {
    setRole(selectedRole);
    if (!isSignUp) {
      if (selectedRole === UserRole.PRINCIPAL) setUsername('principal');
      else if (selectedRole === UserRole.TEACHER) setUsername('teacher');
      else setUsername('student');
      setPassword('school123');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-[128px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-zinc-100 rounded-full blur-[128px]"></div>
      </div>

      <div className="bg-zinc-900/90 backdrop-blur-2xl rounded-[40px] shadow-2xl p-10 w-full max-w-md border border-zinc-800 relative z-10">
        <div className="text-center mb-10">
          <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-white/5 rotate-3 transform hover:rotate-0 transition-all duration-500">
             <i className="fas fa-school text-zinc-950 text-5xl"></i>
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter">VIDYA<span className="text-emerald-500">POINT</span></h1>
          <p className="text-zinc-500 font-bold text-sm mt-2">Unified School Network</p>
        </div>

        <div className="flex bg-zinc-950 rounded-2xl border border-zinc-800 p-1 mb-6">
          <button 
            onClick={() => setIsSignUp(false)}
            className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${!isSignUp ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            Sign In
          </button>
          <button 
            onClick={() => setIsSignUp(true)}
            className={`flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${isSignUp ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
          >
            Sign Up
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 p-1.5 bg-zinc-950 rounded-2xl border border-zinc-800 mb-6">
          {['STUDENT', 'TEACHER', 'PRINCIPAL'].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setDefaults(UserRole[r as keyof typeof UserRole])}
              className={`py-3 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all ${role === UserRole[r as keyof typeof UserRole] ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              {r}
            </button>
          ))}
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          <div className="space-y-3">
            {isSignUp && (
              <div className="relative">
                <i className="fas fa-id-card absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600"></i>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-12 pr-5 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all placeholder:text-zinc-700 font-bold"
                  placeholder="Full Name"
                />
              </div>
            )}
            <div className="relative">
              <i className="fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600"></i>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-12 pr-5 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all placeholder:text-zinc-700 font-bold"
                placeholder="Username"
              />
            </div>
            <div className="relative">
              <i className="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600"></i>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-5 py-4 bg-zinc-950 border border-zinc-800 rounded-2xl text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all placeholder:text-zinc-700 font-bold"
                placeholder="Password"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-white text-zinc-950 font-black py-4 rounded-2xl shadow-xl transition-all transform hover:scale-[1.02] active:scale-95 text-lg"
          >
            {isSignUp ? 'Create Account' : 'Authenticate'}
          </button>
        </form>
      </div>
    </div>
  );
};
