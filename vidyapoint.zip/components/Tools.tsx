
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { useApp } from '../store';

export const Tools: React.FC = () => {
  const { currentUser } = useApp();
  const [activeTool, setActiveTool] = useState<'RESUME' | 'CAREER' | 'PLANNER' | 'ANSWER'>('RESUME');
  const [input, setInput] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAction = async () => {
    setLoading(true);
    setResult(null);
    let res = '';
    if (activeTool === 'RESUME') res = await geminiService.buildResume({ name: currentUser?.name, achievements: input });
    else if (activeTool === 'CAREER') res = await geminiService.suggestCareer(input || currentUser?.bio || 'Student');
    else if (activeTool === 'ANSWER') res = await geminiService.analyzeAnswer(input);
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="bg-zinc-900 rounded-[32px] shadow-2xl overflow-hidden border border-zinc-800">
      <div className="p-1 flex bg-zinc-950 m-6 rounded-2xl border border-zinc-800">
        {['RESUME', 'CAREER', 'ANSWER'].map(t => (
          <button
            key={t}
            onClick={() => {setActiveTool(t as any); setResult(null); setInput('');}}
            className={`flex-1 py-3 rounded-xl text-[9px] font-black tracking-[0.2em] transition-all uppercase ${activeTool === t ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-600 hover:text-zinc-400'}`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="p-8 pt-2 space-y-6">
        <div>
          <h3 className="text-xl font-black text-white tracking-tight">
            {activeTool === 'RESUME' && 'Smart Profile Resume Builder'}
            {activeTool === 'CAREER' && 'AI Future Guidance'}
            {activeTool === 'ANSWER' && 'Score Optimization AI'}
          </h3>
          <p className="text-zinc-500 text-sm font-medium mt-1">
            {activeTool === 'RESUME' && 'Convert your school history into a professional summary.'}
            {activeTool === 'CAREER' && 'Get personalized career paths based on your interests.'}
            {activeTool === 'ANSWER' && 'Paste your answer draft to receive improvement scope.'}
          </p>
        </div>
        
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={activeTool === 'RESUME' ? "List your key achievements, hobbies, and top subjects..." : "Provide context or paste your text for analysis..."}
          className="w-full p-6 bg-zinc-950 border border-zinc-800 rounded-3xl outline-none text-sm text-white font-medium min-h-[180px] focus:ring-2 focus:ring-white/10 transition-all placeholder:text-zinc-800"
        />

        <button
          onClick={handleAction}
          disabled={loading}
          className="w-full bg-white hover:bg-zinc-100 text-zinc-950 font-black py-4 rounded-2xl shadow-xl transition-all transform hover:scale-[1.01] flex items-center justify-center gap-3 disabled:opacity-50"
        >
          {loading ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-sparkles text-emerald-600"></i>}
          Process with School AI
        </button>

        {result && (
          <div className="mt-8 p-8 bg-zinc-950 border border-zinc-800 rounded-3xl text-sm leading-relaxed text-zinc-300 font-medium whitespace-pre-wrap animate-in fade-in slide-in-from-top-4">
            <div className="flex items-center gap-3 mb-6 text-white font-black uppercase tracking-[0.2em] text-[10px]">
              <i className="fas fa-robot text-emerald-500 text-lg"></i> AI INTELLIGENCE REPORT
            </div>
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800/50">
              {result}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
