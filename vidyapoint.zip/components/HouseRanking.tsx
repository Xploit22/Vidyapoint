
import React from 'react';
import { useApp } from '../store';

export const HouseRanking: React.FC = () => {
  // Aggregate house points (mock logic)
  const houses = [
    { name: 'Red House', points: 1250, color: 'rose', icon: 'fire' },
    { name: 'Blue House', points: 1100, color: 'blue', icon: 'water' },
    { name: 'Green House', points: 950, color: 'emerald', icon: 'leaf' },
    { name: 'Yellow House', points: 1400, color: 'amber', icon: 'bolt' }
  ].sort((a,b) => b.points - a.points);

  return (
    <div className="bg-zinc-900 rounded-3xl shadow-xl border border-zinc-800 overflow-hidden">
      <div className="p-8 bg-zinc-800 text-white border-b border-zinc-700">
        <h2 className="text-2xl font-black flex items-center gap-4">
          <i className="fas fa-crown text-amber-500"></i>
          House Leaderboard
        </h2>
        <p className="text-zinc-400 font-medium text-sm mt-2">Current standings for the annual championship.</p>
      </div>
      <div className="p-8 space-y-4">
        {houses.map((house, idx) => (
          <div key={house.name} className="flex items-center gap-6 p-5 bg-zinc-950 border border-zinc-800 rounded-2xl transition-all hover:scale-[1.01]">
            <div className="w-10 text-xl font-black text-zinc-700">#{idx + 1}</div>
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl shadow-xl bg-${house.color}-600`}>
              <i className={`fas fa-${house.icon}`}></i>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-black text-white">{house.name}</h3>
              <div className="w-full bg-zinc-800 h-2 rounded-full mt-2 overflow-hidden">
                <div 
                  className={`bg-${house.color}-500 h-full rounded-full`} 
                  style={{ width: `${(house.points / houses[0].points) * 100}%` }}
                ></div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-black text-white">{house.points}</div>
              <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Points</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
