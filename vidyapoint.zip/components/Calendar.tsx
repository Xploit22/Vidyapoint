
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole } from '../types';

export const Calendar: React.FC = () => {
  const { events, addEvent, currentUser } = useApp();
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newType, setNewType] = useState('EXAM');
  const [newDesc, setNewDesc] = useState('');

  const isStaff = currentUser?.role === UserRole.PRINCIPAL || currentUser?.role === UserRole.TEACHER;

  const handleAdd = () => {
    if (!newTitle || !newDate) return;
    addEvent({
      id: Math.random().toString(36).substr(2, 9),
      title: newTitle,
      date: newDate,
      type: newType,
      description: newDesc
    });
    setShowAdd(false);
    setNewTitle('');
    setNewDate('');
    setNewDesc('');
  };

  const getTypeStyles = (type: string) => {
    switch(type) {
      case 'EXAM': return 'border-red-500/50 bg-red-500/5 text-red-500';
      case 'HOLIDAY': return 'border-green-500/50 bg-green-500/5 text-green-500';
      case 'CULTURAL': return 'border-blue-500/50 bg-blue-500/5 text-blue-500';
      default: return 'border-zinc-800 bg-zinc-900/50 text-zinc-400';
    }
  };

  return (
    <div className="bg-zinc-900 rounded-3xl shadow-xl border border-zinc-800 overflow-hidden">
      <div className="p-8 bg-zinc-800 flex items-center justify-between border-b border-zinc-700">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-4">
            <i className="fas fa-calendar-day text-emerald-500"></i>
            Master Calendar
          </h2>
          <p className="text-zinc-400 text-sm font-medium mt-1">Official academic events & tracking.</p>
        </div>
        {isStaff && (
          <button 
            onClick={() => setShowAdd(!showAdd)}
            className="w-12 h-12 bg-white text-zinc-950 rounded-2xl flex items-center justify-center shadow-lg hover:scale-105 transition-all"
          >
            <i className={`fas ${showAdd ? 'fa-times' : 'fa-plus'}`}></i>
          </button>
        )}
      </div>

      {showAdd && isStaff && (
        <div className="p-8 bg-zinc-950 border-b border-zinc-800 space-y-4 animate-in slide-in-from-top-4">
          <div className="grid grid-cols-2 gap-4">
            <input 
              placeholder="Event Title"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm text-white outline-none"
            />
            <input 
              type="date"
              value={newDate}
              onChange={e => setNewDate(e.target.value)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm text-white outline-none"
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            {['EXAM', 'HOLIDAY', 'CULTURAL'].map(t => (
              <button 
                key={t}
                onClick={() => setNewType(t)}
                className={`py-3 rounded-xl text-[10px] font-black tracking-widest border transition-all ${newType === t ? 'bg-white text-zinc-950 border-white' : 'border-zinc-800 text-zinc-500'}`}
              >
                {t}
              </button>
            ))}
          </div>
          <textarea 
            placeholder="Description..."
            value={newDesc}
            onChange={e => setNewDesc(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm text-white outline-none min-h-[100px]"
          />
          <button 
            onClick={handleAdd}
            className="w-full bg-emerald-600 text-white font-black py-4 rounded-xl shadow-lg hover:bg-emerald-700 transition-all"
          >
            Add to Master Schedule
          </button>
        </div>
      )}

      <div className="p-8 space-y-4">
        <div className="flex gap-4 mb-4">
           <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-zinc-500">
             <div className="w-2 h-2 rounded-full bg-red-500"></div> EXAMS
           </div>
           <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-zinc-500">
             <div className="w-2 h-2 rounded-full bg-green-500"></div> HOLIDAYS
           </div>
           <div className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-zinc-500">
             <div className="w-2 h-2 rounded-full bg-blue-500"></div> CULTURAL
           </div>
        </div>

        {events.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(event => (
          <div key={event.id} className={`flex gap-6 p-6 border rounded-3xl ${getTypeStyles(event.type)} transition-all hover:scale-[1.02] shadow-sm`}>
            <div className="text-center min-w-[60px] flex flex-col justify-center">
              <div className="text-3xl font-black leading-none">{new Date(event.date).getDate()}</div>
              <div className="text-[10px] font-bold uppercase tracking-widest mt-1 opacity-70">
                {new Date(event.date).toLocaleString('default', { month: 'short' })}
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-black tracking-tight">{event.title}</h3>
                <span className="text-[9px] font-black px-3 py-1 bg-white/10 rounded-full tracking-[0.2em]">{event.type}</span>
              </div>
              <p className="text-sm opacity-80 mt-2 font-medium leading-relaxed">{event.description}</p>
            </div>
          </div>
        ))}
        {events.length === 0 && (
          <div className="text-center py-20 text-zinc-600">
            <i className="fas fa-calendar-times text-6xl mb-4 opacity-10"></i>
            <p className="font-black uppercase tracking-widest text-xs">No events scheduled</p>
          </div>
        )}
      </div>
    </div>
  );
};
