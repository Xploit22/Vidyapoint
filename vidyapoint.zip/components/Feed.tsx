
import React, { useState } from 'react';
import { useApp } from '../store';
import { PostCategory, UserRole } from '../types';
import { geminiService } from '../services/geminiService';

export const Feed: React.FC = () => {
  const { posts, addPost, currentUser } = useApp();
  const [newPost, setNewPost] = useState('');
  const [category, setCategory] = useState<PostCategory>(PostCategory.GENERAL);
  const [isModerating, setIsModerating] = useState(false);
  const [warning, setWarning] = useState<string | null>(null);

  const handlePost = async () => {
    if (!newPost.trim() || !currentUser) return;
    setIsModerating(true);
    setWarning(null);
    
    const moderation = await geminiService.moderateContent(newPost);
    
    if (moderation.approved) {
      addPost({
        id: Math.random().toString(36).substr(2, 9),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        content: newPost,
        category,
        timestamp: Date.now(),
        likes: 0,
        isVerified: currentUser.role !== UserRole.STUDENT
      });
      setNewPost('');
    } else {
      // User specifically requested this warning message logic
      setWarning("Hey guys, please be kind to your classmates.");
    }
    setIsModerating(false);
  };

  return (
    <div className="space-y-8">
      {/* Weekly Spotlight Card */}
      <div className="bg-white p-8 rounded-[40px] text-zinc-950 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-emerald-500/20 transition-all"></div>
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-3xl border-4 border-zinc-50 overflow-hidden shadow-2xl rotate-3 group-hover:rotate-0 transition-all duration-500 bg-zinc-100">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Ashish&backgroundColor=c0aede" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400">Campus Hero of the Week</div>
            <h3 className="text-3xl font-black leading-tight mt-1">Ashish Kumar</h3>
            <p className="text-sm font-bold text-zinc-500 mt-1 flex items-center gap-2">
              <i className="fas fa-star text-amber-500"></i> Best contributor in Science Club
            </p>
          </div>
        </div>
        <div className="bg-zinc-950 p-6 rounded-3xl text-center min-w-[120px] shadow-xl">
          <div className="text-3xl font-black text-white">+850</div>
          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-zinc-500 mt-1">Points Gained</div>
        </div>
      </div>

      {/* Post Composer */}
      <div className="bg-zinc-900 rounded-[32px] shadow-2xl p-8 border border-zinc-800">
        <div className="flex gap-6">
          <img src={currentUser?.profilePic} className="w-14 h-14 rounded-2xl object-cover shadow-xl border border-zinc-800 bg-zinc-950" />
          <div className="flex-1">
            <textarea
              placeholder="What's on your mind? Shared achievements or news..."
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-3xl p-6 focus:ring-2 focus:ring-white/10 outline-none min-h-[140px] text-sm font-bold text-white transition-all placeholder:text-zinc-700"
            ></textarea>
            
            {warning && (
              <div className="mt-4 p-5 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-xs text-rose-500 flex items-start gap-4 animate-in slide-in-from-top-4">
                <i className="fas fa-hand-holding-heart text-xl"></i>
                <div className="font-bold">
                  <p className="text-sm">Moderation Note</p>
                  <p className="opacity-80 mt-1">{warning}</p>
                </div>
              </div>
            )}

            <div className="mt-6 flex flex-wrap gap-2">
              {Object.values(PostCategory).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-5 py-2.5 text-[9px] font-black uppercase tracking-widest rounded-xl border transition-all ${category === cat ? 'bg-white text-zinc-950 border-white shadow-xl' : 'bg-zinc-950 text-zinc-500 border-zinc-800 hover:border-zinc-700'}`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex justify-between items-center mt-8">
              <div className="flex gap-4">
                <button className="text-zinc-500 hover:text-white transition-all">
                  <i className="fas fa-image text-xl"></i>
                </button>
                <button className="text-zinc-500 hover:text-white transition-all">
                  <i className="fas fa-paperclip text-xl"></i>
                </button>
              </div>
              <button
                disabled={isModerating || !newPost.trim()}
                onClick={handlePost}
                className="bg-white text-zinc-950 px-10 py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all hover:bg-zinc-200 active:scale-95 shadow-xl shadow-white/5 disabled:opacity-50"
              >
                {isModerating ? <i className="fas fa-shield-halved animate-pulse mr-2"></i> : <i className="fas fa-paper-plane mr-2"></i>}
                {isModerating ? 'Checking...' : 'Publish Post'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Feed List */}
      <div className="space-y-6 pb-20">
        {posts.map((post) => (
          <div key={post.id} className="bg-zinc-900 rounded-[32px] shadow-xl border border-zinc-800 overflow-hidden transition-all hover:border-zinc-700">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${post.userId}&backgroundColor=b6e3f4,c0aede,ffdfbf,d1d4f9`} className="w-12 h-12 rounded-2xl shadow-xl object-cover bg-zinc-950" />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-black text-white leading-none tracking-tight">{post.userName}</h3>
                      {post.isVerified && <i className="fas fa-check-circle text-emerald-500 text-[10px]" title="Official Announcement"></i>}
                    </div>
                    <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest mt-1.5">{post.userRole}</p>
                  </div>
                </div>
                <span className={`text-[9px] font-black uppercase tracking-[0.2em] px-4 py-2 rounded-full border border-zinc-800 bg-zinc-950 text-zinc-500`}>
                  {post.category}
                </span>
              </div>
              <p className="text-zinc-300 text-sm font-bold leading-loose whitespace-pre-wrap">{post.content}</p>
            </div>
            <div className="px-8 py-5 bg-zinc-950/50 flex items-center justify-between border-t border-zinc-800">
              <div className="flex items-center gap-8">
                 <button className="flex items-center gap-2 text-zinc-500 hover:text-rose-500 transition-colors text-[10px] font-black uppercase tracking-widest">
                   <i className="fas fa-heart"></i> {post.likes}
                 </button>
                 <button className="flex items-center gap-2 text-zinc-500 hover:text-emerald-500 transition-colors text-[10px] font-black uppercase tracking-widest">
                   <i className="fas fa-comment-alt"></i> Discuss
                 </button>
              </div>
              <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">
                {new Date(post.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
