
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  PRINCIPAL = 'PRINCIPAL'
}

export enum PostCategory {
  ACADEMICS = 'Academics',
  SPORTS = 'Sports',
  ART = 'Art',
  FEST = 'Fest',
  GENERAL = 'General',
  NEWS = 'School News',
  GALLERY = 'Gallery'
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  class?: string;
  section?: string;
  profilePic: string;
  points: number;
  house?: string;
  club?: string;
  bio?: string;
  achievements?: string[];
  favoriteSubjects?: string[];
  hobbies?: string[];
  skills?: string[];
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  content: string;
  category: PostCategory;
  timestamp: number;
  likes: number;
  isVerified?: boolean;
  image?: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  isModerated: boolean;
}

export interface Poll {
  id: string;
  question: string;
  options: { text: string; votes: number }[];
  voters: string[];
  createdBy: string;
}

export interface Complaint {
  id: string;
  text: string;
  timestamp: number;
  status: 'PENDING' | 'RESOLVED';
}

export interface Report {
  id: string;
  content: string;
  type: string;
  timestamp: number;
  status: 'Unread' | 'Reviewed' | 'Resolved';
}

export interface Event {
  id: string;
  title: string;
  date: string;
  type: string;
  description: string;
}

export interface Resource {
  id: string;
  title: string;
  subject: string;
  type: 'PDF' | 'NOTE' | 'VIDEO' | 'LINK';
  url: string;
  uploadedBy: string;
  timestamp: number;
}

export interface StudyTopic {
  id: string;
  title: string;
  isDone: boolean;
}

export interface Exam {
  id: string;
  userId: string; // To differentiate between student-added and teacher-added
  subject: string;
  date: string; // ISO string
  time: string;
  syllabus: string;
  topics: StudyTopic[];
  color: string;
  isPinned?: boolean;
}
