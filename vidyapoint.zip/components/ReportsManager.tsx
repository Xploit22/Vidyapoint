
import React from 'react';
import { useApp } from '../store';
import { Report } from '../types';

export const ReportsManager: React.FC = () => {
  const { reports, updateReportStatus } = useApp();

  const getStatusColor = (status: Report['status']) => {
    switch (status) {
      case 'Unread': return 'text-rose-500 bg-rose-500/10 border-rose-500/20';
      case 'Reviewed': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
      case 'Resolved': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
      default: return 'text-zinc-500 bg-zinc-500/10 border-zinc-500/20';
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="bg-zinc-900 rounded-[32px] p-8 border border-zinc-800 shadow-2xl">
        <h2 className="text-3xl font-black text-white tracking-tighter">Anonymous Wall Reports</h2>
        <p className="text-zinc-500 font-bold text-sm mt-2">Oversee student concerns and issues submitted anonymously.</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {reports.length === 0 ? (
          <div className="py-20 text-center bg-zinc-900 rounded-[32px] border border-dashed border-zinc-800">
            <i className="fas fa-clipboard-check text-6xl text-zinc-800 mb-6"></i>
            <h4 className="text-zinc-500 font-black uppercase tracking-widest text-sm">No new reports submitted</h4>
          </div>
        ) : (
          reports.sort((a,b) => b.timestamp - a.timestamp).map(report => (
            <div key={report.id} className="bg-zinc-900 rounded-[32px] border border-zinc-800 p-8 flex flex-col md:flex-row gap-8 items-start hover:border-zinc-700 transition-all">
              <div className="flex-1">
                <div className="flex items-center gap-4 mb-4">
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${getStatusColor(report.status)}`}>
                    {report.status}
                  </span>
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">
                    <i className="fas fa-tag mr-2"></i> {report.type}
                  </span>
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">
                    <i className="fas fa-clock mr-2"></i> {new Date(report.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-zinc-200 font-bold leading-relaxed text-lg">"{report.content}"</p>
              </div>
              <div className="flex gap-2">
                {report.status !== 'Resolved' && (
                  <button 
                    onClick={() => updateReportStatus(report.id, report.status === 'Unread' ? 'Reviewed' : 'Resolved')}
                    className="px-6 py-3 bg-white text-zinc-950 font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-zinc-200 transition-all shadow-xl"
                  >
                    {report.status === 'Unread' ? 'Mark as Reviewed' : 'Mark as Resolved'}
                  </button>
                )}
                {report.status === 'Resolved' && (
                  <div className="text-emerald-500 flex items-center gap-2 font-black uppercase tracking-widest text-[10px]">
                    <i className="fas fa-check-circle text-lg"></i> Closed
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
