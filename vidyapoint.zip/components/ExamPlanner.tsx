
import React, { useState, useEffect } from 'react';
import { useApp } from '../store';
import { UserRole, Exam, StudyTopic } from '../types';

export const ExamPlanner: React.FC = () => {
  const { exams, addExam, updateExam, deleteExam, currentUser } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewMode, setViewMode] = useState<'LIST' | 'CALENDAR'>('LIST');
  
  // New Exam Form State
  const [subject, setSubject] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [syllabus, setSyllabus] = useState('');
  const [color, setColor] = useState('blue');
  const [topics, setTopics] = useState<string>('');

  const isStaff = currentUser?.role === UserRole.PRINCIPAL || currentUser?.role === UserRole.TEACHER;

  const handleAddExam = () => {
    if (!subject || !date || !currentUser) return;
    const newExam: Exam = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      subject,
      date: new Date(date).toISOString(),
      time,
      syllabus,
      color,
      topics: topics.split('\n').filter(t => t.trim()).map(t => ({
        id: Math.random().toString(36).substr(2, 9),
        title: t.trim(),
        isDone: false
      })),
      isPinned: isStaff
    };
    addExam(newExam);
    setShowAddModal(false);
    resetForm();
  };

  const resetForm = () => {
    setSubject('');
    setDate('');
    setTime('');
    setSyllabus('');
    setColor('blue');
    setTopics('');
  };

  const toggleTopic = (exam: Exam, topicId: string) => {
    const updatedTopics = exam.topics.map(t => t.id === topicId ? { ...t, isDone: !t.isDone } : t);
    updateExam({ ...exam, topics: updatedTopics });
  };

  const getCountdown = (examDate: string) => {
    const diff = new Date(examDate).getTime() - Date.now();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    if (days < 0) return 'Passed';
    if (days === 0) return 'Today!';
    return `${days} days left`;
  };

  const getProgress = (exam: Exam) => {
    if (exam.topics.length === 0) return 0;
    const done = exam.topics.filter(t => t.isDone).length;
    return Math.round((done / exam.topics.length) * 100);
  };

  const colors = [
    { name: 'Blue', value: 'blue', bg: 'bg-blue-500/10', border: 'border-blue-500/30', text: 'text-blue-500' },
    { name: 'Green', value: 'green', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', text: 'text-emerald-500' },
    { name: 'Yellow', value: 'yellow', bg: 'bg-amber-500/10', border: 'border-amber-500/30', text: 'text-amber-500' },
    { name: 'Rose', value: 'rose', bg: 'bg-rose-500/10', border: 'border-rose-500/30', text: 'text-rose-500' }
  ];

  return (
    <div className="space-y-8 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter">Exam Planner</h2>
          <p className="text-zinc-500 font-bold text-sm mt-1">Stay ahead, track your prep, ace your tests.</p>
        </div>
        <div className="flex bg-zinc-900 rounded-2xl p-1 border border-zinc-800">
           <button 
             onClick={() => setViewMode('LIST')}
             className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'LIST' ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-500'}`}
           >
             <i className="fas fa-list mr-2"></i> List
           </button>
           <button 
             onClick={() => setViewMode('CALENDAR')}
             className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'CALENDAR' ? 'bg-white text-zinc-950 shadow-lg' : 'text-zinc-500'}`}
           >
             <i className="fas fa-calendar mr-2"></i> Calendar
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {exams.map(exam => {
          const colorObj = colors.find(c => c.value === exam.color) || colors[0];
          const progress = getProgress(exam);
          const countdown = getCountdown(exam.date);
          
          return (
            <div key={exam.id} className={`bg-zinc-900 rounded-[32px] border ${colorObj.border} p-8 shadow-xl transition-all hover:scale-[1.01] flex flex-col`}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-black text-white">{exam.subject}</h3>
                    {exam.isPinned && <i className="fas fa-thumbtack text-[10px] text-zinc-500 rotate-45"></i>}
                  </div>
                  <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1">
                    <i className="fas fa-clock mr-2"></i> {new Date(exam.date).toLocaleDateString()} @ {exam.time}
                  </div>
                </div>
                <div className={`px-4 py-2 rounded-2xl ${colorObj.bg} ${colorObj.text} text-[10px] font-black uppercase tracking-widest`}>
                  {countdown}
                </div>
              </div>

              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                   <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Preparation Progress</span>
                   <span className={`text-[10px] font-black ${colorObj.text}`}>{progress}%</span>
                </div>
                <div className="w-full h-2.5 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
                  <div className={`h-full ${colorObj.text.replace('text', 'bg')} transition-all duration-700`} style={{ width: `${progress}%` }}></div>
                </div>
              </div>

              <div className="flex-1 space-y-3">
                 <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mb-3">Study Checklist</h4>
                 {exam.topics.map(topic => (
                   <div key={topic.id} onClick={() => toggleTopic(exam, topic.id)} className="flex items-center gap-4 group cursor-pointer">
                      <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition-all ${topic.isDone ? `${colorObj.text.replace('text', 'bg')} border-transparent` : 'border-zinc-800 group-hover:border-zinc-700'}`}>
                        {topic.isDone && <i className="fas fa-check text-[8px] text-zinc-950"></i>}
                      </div>
                      <span className={`text-sm font-bold transition-all ${topic.isDone ? 'text-zinc-600 line-through' : 'text-zinc-300'}`}>
                        {topic.title}
                      </span>
                   </div>
                 ))}
                 {exam.topics.length === 0 && <p className="text-xs text-zinc-600 italic">No checklist added.</p>}
              </div>

              <div className="mt-8 pt-6 border-t border-zinc-800 flex justify-between items-center">
                 <div className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">
                   {exam.isPinned ? 'Teacher Schedule' : 'Personal Plan'}
                 </div>
                 {!exam.isPinned && (
                   <button onClick={() => deleteExam(exam.id)} className="text-zinc-600 hover:text-rose-500 transition-all">
                     <i className="fas fa-trash-alt text-sm"></i>
                   </button>
                 )}
              </div>
            </div>
          );
        })}

        {exams.length === 0 && (
          <div className="col-span-full py-20 text-center bg-zinc-900/50 rounded-[40px] border border-dashed border-zinc-800">
             <i className="fas fa-book-reader text-6xl text-zinc-800 mb-6"></i>
             <h4 className="text-zinc-500 font-black uppercase tracking-widest text-sm">Your planner is empty. Start prep now!</h4>
          </div>
        )}
      </div>

      {/* FAB */}
      <button 
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-10 right-10 w-16 h-16 bg-white text-zinc-950 rounded-3xl shadow-2xl flex items-center justify-center text-2xl hover:scale-110 active:scale-90 transition-all z-40 group"
      >
        <i className="fas fa-plus group-hover:rotate-90 transition-all duration-300"></i>
      </button>

      {/* Add Exam Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-md z-50 flex items-center justify-center p-6">
          <div className="bg-zinc-900 w-full max-w-lg rounded-[40px] border border-zinc-800 shadow-2xl p-10 animate-in zoom-in-95">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-white tracking-tight">Schedule New Exam</h2>
              <button onClick={() => setShowAddModal(false)} className="text-zinc-500 hover:text-white">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            
            <div className="space-y-5">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Subject Name</label>
                <input 
                  type="text" 
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none focus:ring-2 focus:ring-white/10"
                  placeholder="e.g. Computer Science"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Date</label>
                  <input 
                    type="date" 
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Time</label>
                  <input 
                    type="time" 
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-bold outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Color Code</label>
                <div className="flex gap-3 px-1">
                   {colors.map(c => (
                     <button 
                       key={c.value}
                       onClick={() => setColor(c.value)}
                       className={`w-10 h-10 rounded-xl transition-all border-4 ${color === c.value ? 'border-white scale-110 shadow-lg' : 'border-transparent'} ${c.text.replace('text', 'bg')}`}
                     />
                   ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Study Topics (One per line)</label>
                <textarea 
                  value={topics}
                  onChange={e => setTopics(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-4 text-white font-medium outline-none min-h-[100px] text-sm"
                  placeholder="Chapter 1 Review&#10;Solve Sample Paper&#10;Formula Sheet..."
                />
              </div>

              <button 
                onClick={handleAddExam}
                className="w-full bg-white text-zinc-950 py-5 rounded-2xl font-black uppercase tracking-widest text-sm shadow-xl hover:bg-zinc-200 transition-all mt-4"
              >
                Add to Planner
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
