
import React from 'react';
import { useApp } from '../store';

const LANGUAGES = [
  { id: 'en', name: 'English', native: 'English', icon: '🇺🇸' },
  { id: 'hi', name: 'Hindi', native: 'हिन्दी', icon: '🇮🇳' },
  { id: 'bn', name: 'Bengali', native: 'বাংলা', icon: '🇧🇩' },
  { id: 'es', name: 'Spanish', native: 'Español', icon: '🇪🇸' },
  { id: 'fr', name: 'French', native: 'Français', icon: '🇫🇷' },
  { id: 'de', name: 'German', native: 'Deutsch', icon: '🇩🇪' },
];

export const LanguagePicker: React.FC = () => {
  const { setSessionLanguage, currentUser } = useApp();

  const handleSelect = (lang: string) => {
    setSessionLanguage(lang);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-[128px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-zinc-100 rounded-full blur-[128px]"></div>
      </div>

      <div className="bg-zinc-900/90 backdrop-blur-2xl rounded-[40px] shadow-2xl p-10 w-full max-w-2xl border border-zinc-800 relative z-10 animate-in zoom-in-95 duration-500">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-white/5 rotate-3">
             <i className="fas fa-language text-zinc-950 text-4xl"></i>
          </div>
          <h2 className="text-3xl font-black text-white tracking-tighter">Choose Your Language</h2>
          <p className="text-zinc-500 font-bold text-sm mt-2">Welcome, {currentUser?.name}! Select your preferred language to continue.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.id}
              onClick={() => handleSelect(lang.id)}
              className="group bg-zinc-950 border border-zinc-800 p-6 rounded-3xl flex flex-col items-center gap-3 transition-all hover:border-emerald-500/50 hover:bg-zinc-900 shadow-lg hover:scale-105 active:scale-95"
            >
              <span className="text-4xl">{lang.icon}</span>
              <div className="text-center">
                <div className="text-white font-black text-sm group-hover:text-emerald-500 transition-colors">{lang.native}</div>
                <div className="text-zinc-600 font-bold text-[10px] uppercase tracking-widest">{lang.name}</div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-10 text-center">
          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em]">You can change this anytime in your profile settings.</p>
        </div>
      </div>
    </div>
  );
};
