
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  async moderateContent(text: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this post for a school social network: "${text}"`,
        config: {
          systemInstruction: `You are a strict but gentle school content moderator. 
          Your goal is to maintain a safe, positive, and bullying-free environment.
          
          CRITERIA FOR REJECTION (approved: false):
          1. Direct insults (e.g., "loser", "stupid", "idiot").
          2. Academic shaming (e.g., "fails every exam", "dumbest in class").
          3. Hate speech, harassment, or toxic language.
          4. Any form of cyberbullying directed at individuals.

          CRITERIA FOR APPROVAL (approved: true):
          1. General positive feedback.
          2. Neutral school updates.
          3. Constructive academic discussions.

          Return JSON with 'approved' (boolean), 'reason' (string), and 'sentiment' (string).`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              approved: { type: Type.BOOLEAN },
              reason: { type: Type.STRING },
              sentiment: { type: Type.STRING }
            },
            required: ["approved", "reason", "sentiment"]
          }
        }
      });
      return JSON.parse(response.text || '{"approved": true, "reason": "", "sentiment": "neutral"}');
    } catch { 
      // Default to safe side if API fails - usually better to allow neutral if unknown or block if risky.
      // Here we assume it's approved but in a real production app we might queue for human review.
      return { approved: true, reason: "", sentiment: "neutral" }; 
    }
  },

  async solveDoubt(question: string, subject: string, language: string = 'English', imageData?: string) {
    try {
      const parts: any[] = [{ text: `Subject: ${subject}, Question: ${question}, Language: ${language}. Provide a step-by-step school-appropriate explanation. If the question is outside school syllabus or inappropriate, gently decline.` }];
      
      if (imageData) {
        parts.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: imageData.split(',')[1] // remove data:image/jpeg;base64,
          }
        });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts },
        config: {
          systemInstruction: "You are a school-safe AI tutor. Solve the doubt based on the text or image provided. Keep explanations simple, encouraging, and clear for students. Do not encourage cheating.",
        }
      });
      return response.text;
    } catch { return "Error solving doubt."; }
  },

  async extractSkills(profileData: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Based on this student profile: "${profileData}", extract 5 key positive skills or strengths.`,
        config: {
          systemInstruction: "Extract positive academic or creative skills for a school student. Be encouraging.",
        }
      });
      return response.text?.split(',').map(s => s.trim()) || [];
    } catch { return []; }
  },

  async buildResume(userData: any) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Create a professional student resume for: ${JSON.stringify(userData)}`,
        config: {
          systemInstruction: "You are a professional career counselor. Create a well-formatted Markdown resume for a school student. Include a summary, skills, achievements, and interests. Use a clean and professional tone.",
        }
      });
      return response.text;
    } catch {
      return "Could not generate resume. Please try again later.";
    }
  },

  async analyzeAnswer(answer: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this student answer: "${answer}"`,
        config: {
          systemInstruction: "Provide constructive feedback, highlight key terms for marks, and suggest improvement scopes like keyword highlighting.",
        }
      });
      return response.text;
    } catch { return "Could not analyze answer."; }
  },

  async suggestCareer(profile: string) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `User Profile and History: ${profile}`,
        config: {
          systemInstruction: "Recommend school student career paths based on this profile's history, interests, and strengths. Provide clear, actionable advice.",
        }
      });
      return response.text;
    } catch { return "Career insights unavailable."; }
  }
};
