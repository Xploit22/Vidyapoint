
import React, { useState } from 'react';
import { useApp } from '../store';
import { UserRole } from '../types';

export const Polls: React.FC = () => {
  const { polls, setPolls, currentUser } = useApp();
  const [showAdd, setShowAdd] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  const isStaff = currentUser?.role === UserRole.PRINCIPAL || currentUser?.role === UserRole.TEACHER;

  const handleVote = (pollId: string, optionIndex: number) => {
    if (!currentUser) return;
    setPolls(prev => prev.map(p => {
      if (p.id === pollId && !p.voters.includes(currentUser.id)) {
        const newOptions = [...p.options];
        newOptions[optionIndex].votes += 1;
        return { ...p, options: newOptions, voters: [...p.voters, currentUser.id] };
      }
      return p;
    }));
  };

  const addPoll = () => {
    if (!question || options.some(o => !o)) return;
    const newPoll = {
      id: Math.random().toString(36).substr(2, 9),
      question,
      options: options.map(o => ({ text: o, votes: 0 })),
      voters: [],
      createdBy: currentUser?.id || 'system'
    };
    setPolls(prev => [newPoll, ...prev]);
    setQuestion('');
    setOptions(['', '']);
    setShowAdd(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-2xl font-black text-white tracking-tight px-2">Campus Polls</h3>
        {isStaff && (
          <button 
            onClick={() => setShowAdd(!showAdd)}
            className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/20"
          >
            <i className="fas fa-plus"></i> New Poll
          </button>
        )}
      </div>

      {showAdd && isStaff && (
        <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 space-y-4 animate-in slide-in-from-top-4">
          <input 
            placeholder="Poll Question..."
            value={question}
            onChange={e => setQuestion(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-sm text-white outline-none"
          />
          {options.map((opt, idx) => (
            <input 
              key={idx}
              placeholder={`Option ${idx + 1}`}
              value={opt}
              onChange={e => {
                const newOpts = [...options];
                newOpts[idx] = e.target.value;
                setOptions(newOpts);
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm text-zinc-300 outline-none"
            />
          ))}
          <div className="flex gap-2">
            <button 
              onClick={() => setOptions([...options, ''])}
              className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded-xl text-[9px] font-black uppercase tracking-widest"
            >
              Add Option
            </button>
            <button 
              onClick={addPoll}
              className="flex-1 py-2 bg-white text-zinc-950 rounded-xl text-[9px] font-black uppercase tracking-widest"
            >
              Create Poll
            </button>
          </div>
        </div>
      )}

      {polls.map(poll => (
        <div key={poll.id} className="bg-zinc-900 p-8 rounded-[32px] border border-zinc-800 shadow-xl transition-all hover:border-zinc-700">
          <div className="flex items-start justify-between mb-6">
            <h3 className="text-lg font-black text-white leading-tight tracking-tight">{poll.question}</h3>
            <span className="text-[8px] font-black uppercase tracking-[0.2em] bg-zinc-950 text-zinc-500 px-3 py-1.5 rounded-full border border-zinc-800">CAMPUS VOTE</span>
          </div>
          <div className="space-y-3">
            {poll.options.map((opt, idx) => {
              const total = poll.options.reduce((a, b) => a + b.votes, 0);
              const percentage = total === 0 ? 0 : Math.round((opt.votes / total) * 100);
              const hasVoted = poll.voters.includes(currentUser?.id || '');

              return (
                <button
                  key={idx}
                  disabled={hasVoted}
                  onClick={() => handleVote(poll.id, idx)}
                  className={`relative w-full p-5 rounded-2xl border transition-all text-left overflow-hidden group ${hasVoted ? 'border-zinc-800 cursor-default' : 'border-zinc-800 hover:border-white/20 hover:bg-zinc-800/50'}`}
                >
                  <div 
                    className="absolute inset-0 bg-white/5 transition-all duration-700" 
                    style={{ width: `${percentage}%`, opacity: hasVoted ? 1 : 0 }}
                  ></div>
                  <div className="relative flex justify-between items-center z-10">
                    <span className={`text-sm font-bold ${hasVoted ? 'text-zinc-300' : 'text-zinc-500 group-hover:text-zinc-300'}`}>{opt.text}</span>
                    {hasVoted && (
                      <div className="flex items-center gap-3">
                        <div className="text-[10px] font-black text-white">{percentage}%</div>
                        <div className="w-8 h-1 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500" style={{ width: `${percentage}%` }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-6 flex items-center justify-between">
            <p className="text-[9px] text-zinc-500 font-black uppercase tracking-[0.2em]">
              {poll.voters.length} total votes • {poll.voters.includes(currentUser?.id || '') ? 'Decision logged' : 'Waiting for your vote'}
            </p>
            <div className="flex -space-x-2">
              {[1,2,3].map(i => (
                <div key={i} className="w-5 h-5 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center text-[6px] text-zinc-500 font-black">
                  {i}
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
